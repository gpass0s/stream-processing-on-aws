""" Version information """

__version__ = "2.4.1"
__version_info__ = (2, 4, 1)
